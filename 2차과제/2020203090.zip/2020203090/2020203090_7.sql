select distinct ID
from student

except

select distinct ID
from takes
;