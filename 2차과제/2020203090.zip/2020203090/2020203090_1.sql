select name
from instructor
where dept_name = 'Physics'
;